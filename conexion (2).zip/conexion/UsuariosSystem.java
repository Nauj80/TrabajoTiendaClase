package conexion;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class UsuariosSystem implements Crud<Usuarios> {
    
    // Atributos de la conexión a la base de datos
    private final Conexion conectar = Conexion.getInstance();
    
    @Override
    public List<Usuarios> listar() {
        List<Usuarios> datos = new ArrayList<>();
        String sql = "SELECT * FROM usuarios";
        
        // Consulta de usuarios
        try (Connection con = conectar.getConnection(); 
             PreparedStatement ps = con.prepareStatement(sql); 
             ResultSet rs = ps.executeQuery()) {
            
            // Recorrer los resultados
            while (rs.next()) {
                Usuarios uu = new Usuarios();
                uu.setNombre(rs.getString(1));
                uu.setCorreo(rs.getString(2));
                uu.setContraseña(rs.getString(3));
                datos.add(uu);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "Error de Consulta", JOptionPane.ERROR_MESSAGE);
        }
        
        return datos;
    }

    @Override
    public int setAgregar(Usuarios u) {
        String sql = "INSERT INTO usuarios(nombre, correo, contraseña) VALUES(?, ?, ?)";
        int result = 0;
        
        // Agregar un nuevo usuario
        try (Connection con = conectar.getConnection(); 
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, u.getNombre());
            ps.setString(2, u.getCorreo());
            ps.setString(3, u.getContraseña());
            
            result = ps.executeUpdate();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "Error de Inserción", JOptionPane.ERROR_MESSAGE);
        }
        
        return result;
    }

    @Override
    public int setEliminar(int id) {
        String sql = "DELETE FROM usuarios WHERE id = ?";
        int result = 0;
        
        // Eliminar usuario
        try (Connection con = conectar.getConnection(); 
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setInt(1, id);
            result = ps.executeUpdate();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "Error de Eliminación", JOptionPane.ERROR_MESSAGE);
        }
        
        return result;
    }
    @Override
    public int setActualizar(Usuarios u) {
        String sql = "UPDATE usuarios SET nombre=?, correo=?, contraseña=?";

        try (
            Connection con = conectar.getConnection(); 
             PreparedStatement ps = con.prepareStatement(sql)) 
        {
            ps.setString(1, u.getNombre());
            ps.setString(2, u.getCorreo());
            ps.setString(3, u.getContraseña());
            return ps.executeUpdate();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "Error de Actualización", JOptionPane.ERROR_MESSAGE);
            return 0;
        }
    }
}
