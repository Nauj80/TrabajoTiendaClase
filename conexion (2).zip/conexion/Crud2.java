package conexion;


import java.util.List;

public interface Crud2<T> {
    List<T> listar();
}
    //int setActualizar(T tr);
