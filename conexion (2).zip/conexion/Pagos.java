package conexion;

/**
 *
 * @author Miguel Angel Tejada
 */
public class Pagos {
    private int id;
    private String nombre;

    public Pagos() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
