package conexion;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class Detalle_transaccionSystem implements Crud<Detalle_transaccion> {
    
    Conexion conectar = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;

    @Override
    public List<Detalle_transaccion> listar() {
        List<Detalle_transaccion> datos = new ArrayList<>();
        String sql = "SELECT * FROM detalle_transaccion";
        String sql2 = "SELECT u.id, u.nombre, p.nombre, t.total, pa.nombre FROM transacciones t INNER JOIN usuarios u ON t.usuario_id = u.id INNER JOIN detalle_transaccion dt ON dt.transaccion_id = t.id INNER JOIN productos p ON dt.producto_id = p.id INNER JOIN pagos pa ON t.pago_id = pa.id;";
        
        try {
            con = conectar.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Detalle_transaccion d = new Detalle_transaccion();
                d.setId(rs.getInt("id"));
                d.setTransaccion_id(rs.getInt("transaccion_id"));
                d.setProducto_id(rs.getInt("producto_id"));
                d.setCantidad(rs.getInt("cantidad"));
                d.setPrecio_unitario(rs.getDouble("precio_unitario"));
                datos.add(d);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "Error de Consulta", JOptionPane.ERROR_MESSAGE);
        } finally {
            try { con.close(); } catch (Exception e) {}
        }
        return datos;
    }

    @Override
    public int setAgregar(Detalle_transaccion d) {
        String sql = "INSERT INTO detalle_transaccion(transaccion_id, producto_id, cantidad, precio_unitario) VALUES(?, ?, ?, ?)";
        try {
            con = conectar.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, d.getTransaccion_id());
            ps.setInt(2, d.getProducto_id());
            ps.setInt(3, d.getCantidad());
            ps.setDouble(4, d.getPrecio_unitario());
            return ps.executeUpdate();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "Error de Inserción", JOptionPane.ERROR_MESSAGE);
            return 0;
        } finally {
            try { con.close(); } catch (Exception e) {}
        }
    }

    @Override
    public int setEliminar(int id) {
        String sql = "DELETE FROM detalle_transaccion WHERE id = ?";
        try {
            con = conectar.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
            return 1;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "Error de Eliminación", JOptionPane.ERROR_MESSAGE);
            return 0;
        } finally {
            try { con.close(); } catch (Exception e) {}
        }
    }

    @Override
    public int setActualizar(Detalle_transaccion d) {
        String sql = "UPDATE detalle_transaccion SET transaccion_id = ?, producto_id = ?, cantidad = ?, precio_unitario = ? WHERE id = ?";
        try (Connection con = conectar.getConnection(); 
             PreparedStatement ps = con.prepareStatement(sql)) {

            // Establecer los parámetros del PreparedStatement
            ps.setInt(1, d.getTransaccion_id());
            ps.setInt(2, d.getProducto_id());
            ps.setInt(3, d.getCantidad());
            ps.setDouble(4, d.getPrecio_unitario());
            ps.setInt(5, d.getId()); // ID del detalle de la transacción que se debe actualizar

            return ps.executeUpdate();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "Error de Actualización", JOptionPane.ERROR_MESSAGE);
            return 0;
        }
    }
}
