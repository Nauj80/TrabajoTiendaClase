package conexion;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class PagosSystem implements Crud<Pagos> {
    
    Conexion conectar = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;

    @Override
    public List<Pagos> listar() {
        List<Pagos> datos = new ArrayList<>();
        String sql = "SELECT * FROM pagos";
        try {
            con = conectar.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Pagos p = new Pagos();
                p.setId(rs.getInt("id"));
                p.setNombre(rs.getString("nombre"));
                datos.add(p);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "Error de Consulta", JOptionPane.ERROR_MESSAGE);
        } finally {
            try { con.close(); } catch (Exception e) {}
        }
        return datos;
    }

    @Override
    public int setAgregar(Pagos p) {
        String sql = "INSERT INTO pagos(nombre) VALUES(?)";
        try {
            con = conectar.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, p.getNombre());
            return ps.executeUpdate();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "Error de Inserción", JOptionPane.ERROR_MESSAGE);
            return 0;
        } finally {
            try { con.close(); } catch (Exception e) {}
        }
    }

    @Override
    public int setEliminar(int id) {
        String sql = "DELETE FROM pagos WHERE id = ?";
        try {
            con = conectar.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
            return 1;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "Error de Eliminación", JOptionPane.ERROR_MESSAGE);
            return 0;
        } finally {
            try { con.close(); } catch (Exception e) {}
        }
    }

    @Override
    public int setActualizar(Pagos p) {
        String sql = "UPDATE pagos SET nombre = ? WHERE id = ?";
        try (Connection con = conectar.getConnection(); 
             PreparedStatement ps = con.prepareStatement(sql)) {

            // Establecemos los parámetros del PreparedStatement
            ps.setString(1, p.getNombre());
            ps.setInt(2, p.getId()); // ID del pago que se debe actualizar

            // Ejecutar la actualización
            return ps.executeUpdate();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "Error de Actualización", JOptionPane.ERROR_MESSAGE);
            return 0;
        }
    }
}
