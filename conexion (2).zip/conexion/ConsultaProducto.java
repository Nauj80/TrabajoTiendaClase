package conexion;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class ConsultaProducto implements Crud2<Detalle> {

   Conexion conectar = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    
    public List<Detalle> listar(){
        List<Detalle> datos=new ArrayList<>();
    String sql = "SELECT u.id, u.nombre, p.nombre, t.total, pa.nombre FROM transacciones t INNER JOIN usuarios u ON t.usuario_id = u.id INNER JOIN detalle_transaccion dt ON dt.transaccion_id = t.id INNER JOIN productos p ON dt.producto_id = p.id INNER JOIN pagos pa ON t.pago_id = pa.id;";
        
        try{
            con=conectar.getConnection();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            
            while(rs.next()){
                Detalle D=new Detalle();
                D.setUsuarioId(rs.getInt("id"));
                D.setUsuarioNombre(rs.getString("nombre"));
                D.setProductoNombre(rs.getString("nombre"));
                D.setTotal(rs.getDouble("total"));
                D.setPagoNombre(rs.getString("nombre"));
                datos.add(D);
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e.toString(),"Error de Consulta",JOptionPane.ERROR_MESSAGE);
        }finally{
            try{ con.close(); }catch(Exception e){}
        }
        return datos;
    }
}