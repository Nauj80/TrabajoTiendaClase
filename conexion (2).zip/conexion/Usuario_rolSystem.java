package conexion;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class Usuario_rolSystem implements Crud<Usuario_rol> {
    
    Conexion conectar = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;

    @Override
    public List<Usuario_rol> listar() {
        List<Usuario_rol> datos = new ArrayList<>();
        String sql = "SELECT * FROM usuario_rol";
        try {
            con = conectar.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            
            while (rs.next()) {
                Usuario_rol ur = new Usuario_rol();
                ur.setId_usuario_rol(rs.getInt("id_usuario_rol"));
                ur.setId_usuario(rs.getInt("id_usuario"));
                ur.setId_rol(rs.getInt("id_rol"));
                datos.add(ur);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "Error de Consulta", JOptionPane.ERROR_MESSAGE);
        } finally {
            try { con.close(); } catch (Exception e) {}
        }
        return datos;
    }

    @Override
    public int setAgregar(Usuario_rol ur) {
        String sql = "INSERT INTO usuario_rol(id_usuario, id_rol) VALUES(?, ?)";
        try {
            con = conectar.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, ur.getId_usuario());
            ps.setInt(2, ur.getId_rol());
            return ps.executeUpdate();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "Error de Inserción", JOptionPane.ERROR_MESSAGE);
            return 0;
        } finally {
            try { con.close(); } catch (Exception e) {}
        }
    }

    @Override
    public int setEliminar(int id) {
        String sql = "DELETE FROM usuario_rol WHERE id_usuario_rol = ?";
        try {
            con = conectar.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
            return 1;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "Error de Eliminación", JOptionPane.ERROR_MESSAGE);
            return 0;
        } finally {
            try { con.close(); } catch (Exception e) {}
        }
    }

    @Override
    public int setActualizar(Usuario_rol ur) {
        String sql = "UPDATE usuario_rol SET id_usuario = ?, id_rol = ? WHERE id_usuario_rol = ?";
        try (Connection con = conectar.getConnection(); 
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            // Establecer los valores de los parámetros
            ps.setInt(1, ur.getId_usuario());
            ps.setInt(2, ur.getId_rol());
            ps.setInt(3, ur.getId_usuario_rol());
            
            // Ejecutar la actualización
            return ps.executeUpdate();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "Error de Actualización", JOptionPane.ERROR_MESSAGE);
            return 0;
        }
    }
}
