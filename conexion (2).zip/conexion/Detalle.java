package conexion;


public class Detalle {
    private int usuarioId;
    private String usuarioNombre;
    private String productoNombre;
    private double total;
    private String pagoNombre;
    public Detalle(){
    }

    public int getUsuarioId() { 
        return usuarioId; 
    }
    public void setUsuarioId(int usuarioId) { 
        this.usuarioId = usuarioId; 
    }

    public String getUsuarioNombre() { 
        return usuarioNombre; 
    }
    public void setUsuarioNombre(String usuarioNombre) { 
        this.usuarioNombre = usuarioNombre; 
    }

    public String getProductoNombre() { 
        return productoNombre; 
    }
    public void setProductoNombre(String productoNombre) { 
        this.productoNombre = productoNombre; 
    }

    public double getTotal() { 
        return total; 
    }
    public void setTotal(double total) { 
        this.total = total; 
    }

    public String getPagoNombre() { 
        return pagoNombre; 
    }
    public void setPagoNombre(String pagoNombre) { 
        this.pagoNombre = pagoNombre; 
    }
}
