package conexion;

import java.util.List;

public interface Crud<T> {
    List<T> listar();
    int setAgregar(T tr);
     int setEliminar(int id);
    int setActualizar(T tr);
}

