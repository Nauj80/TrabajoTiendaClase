package conexion;

public class Roles {
    private int id;
    private String nombre;
    public Roles() {
    }

    public Roles(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    public int getIdRol() {
        return id;
    }

    public void setIdRol(int id) {
        this.id = id;
    }

    public String getNombreRol() {
        return nombre;
    }

    public void setNombreRol(String nombre) {
        this.nombre = nombre;
    }
    
}
