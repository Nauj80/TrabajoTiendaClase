package conexion;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class TransaccionesSystem implements Crud<Transacciones> {
    Conexion conectar = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;

    @Override
    public List<Transacciones> listar() {
        List<Transacciones> datos = new ArrayList<>();
        String sql = "SELECT * FROM transacciones";
        try {
            con = conectar.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Transacciones t = new Transacciones();
                t.setId(rs.getInt("id"));
                t.setUsuario_id(rs.getInt("usuario_id"));
                t.setFecha(rs.getString("fecha"));
                t.setPago_id(rs.getInt("pago_id"));
                t.setTotal(rs.getDouble("total"));
                datos.add(t);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "Error de Consulta", JOptionPane.ERROR_MESSAGE);
        } finally {
            try {
                con.close();
            } catch (Exception e) {}
        }
        return datos;
    }

    @Override
    public int setAgregar(Transacciones t) {
        String sql = "INSERT INTO transacciones(usuario_id, fecha, pago_id, total) VALUES(?, ?, ?, ?)";
        try {
            con = conectar.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, t.getUsuario_id());
            ps.setString(2, t.getFecha());
            ps.setInt(3, t.getPago_id());
            ps.setDouble(4, t.getTotal());
            return ps.executeUpdate();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "Error de Inserción", JOptionPane.ERROR_MESSAGE);
            return 0;
        } finally {
            try { con.close(); } catch (Exception e) {}
        }
    }

    @Override
    public int setEliminar(int id) {
        String sql = "DELETE FROM transacciones WHERE id = ?";
        try {
            con = conectar.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
            return 1;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "Error de Eliminación", JOptionPane.ERROR_MESSAGE);
            return 0;
        } finally {
            try { con.close(); } catch (Exception e) {}
        }
    }

    @Override
    public int setActualizar(Transacciones t) {
        String sql = "UPDATE transacciones SET usuario_id = ?, fecha = ?, pago_id = ?, total = ? WHERE id = ?";
        try (Connection con = conectar.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            // Establecemos los parámetros del PreparedStatement
            ps.setInt(1, t.getUsuario_id());
            ps.setString(2, t.getFecha());
            ps.setInt(3, t.getPago_id());
            ps.setDouble(4, t.getTotal());
            ps.setInt(5, t.getId()); // Se pasa el ID de la transacción para identificar la que se actualizará

            // Ejecutar la actualización
            return ps.executeUpdate();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "Error de Actualización", JOptionPane.ERROR_MESSAGE);
            return 0;
        }
    }
}
