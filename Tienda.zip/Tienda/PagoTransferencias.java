package Tienda;

public class PagoTransferencias implements Pagos {
    private String banco;

    public PagoTransferencias() {
        this.banco = "Banco Nacional";
    }

    @Override
    public void crearPago() {
        System.out.println("Pago mediante transferencia realizado desde: " + banco);
    }
}
