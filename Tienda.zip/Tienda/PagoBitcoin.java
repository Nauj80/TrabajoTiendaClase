package Tienda;

public class PagoBitcoin implements Pagos {
    private String wallet;
    private double monto;

    public PagoBitcoin(String wallet, double monto) {
        this.wallet = wallet;
        this.monto = monto;
    }

    @Override
    public void crearPago() {
        System.out.println("Pago de " + monto + " BTC enviado a la wallet: " + wallet);
    }
}
