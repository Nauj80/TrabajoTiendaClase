package Tienda;



public class Tienda {
    public static void main(String[] args) {
    }    
}
