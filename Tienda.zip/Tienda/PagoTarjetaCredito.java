package Tienda;

public class PagoTarjetaCredito implements Pagos {
    private String numeroTarjeta;
    private String titular;
    private String fechaVencimiento;

    public PagoTarjetaCredito(String numeroTarjeta, String titular, String fechaVencimiento) {
        this.numeroTarjeta = numeroTarjeta;
        this.titular = titular;
        this.fechaVencimiento = fechaVencimiento;
    }

    @Override
    public void crearPago() {
        System.out.println("Pago con tarjeta de crédito de " + titular + " procesado");
    }
}
