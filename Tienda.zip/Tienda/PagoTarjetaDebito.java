package Tienda;

public class PagoTarjetaDebito implements Pagos {
    private String numeroTarjeta;

    public PagoTarjetaDebito() {
        this.numeroTarjeta = "**** **** **** 1234"; // ocultar dígitos
    }

    @Override
    public void crearPago() {
        System.out.println("Pago con tarjeta de débito procesado: " + numeroTarjeta);
    }
}
