package Tienda;

public class PagoApplePay implements Pagos {
    private String dispositivo;
    private String usuario;

    public PagoApplePay(String dispositivo, String usuario) {
        this.dispositivo = dispositivo;
        this.usuario = usuario;
    }
    @Override
    public void crearPago() {
        System.out.println("Pago con Apple Pay desde " + dispositivo + " para usuario " + usuario);
    }
}
