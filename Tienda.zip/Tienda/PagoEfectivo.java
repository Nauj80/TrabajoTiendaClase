package Tienda;

public class PagoEfectivo implements Pagos {
    private String moneda = "COP";
    private double monto = 50000;

    @Override
    public void crearPago() {
        System.out.println("Pago en efectivo de " + monto + " " + moneda + " realizado.");
    }
}
