package Tienda;

public class PagoConsignacion implements Pagos {
    private String banco;
    private String cuenta;

    public PagoConsignacion(String banco, String cuenta) {
        this.banco = banco;
        this.cuenta = cuenta;
    }
    @Override
    public void crearPago() {
        System.out.println("Consignación realizada en el banco " + banco + " cuenta: " + cuenta);
    }
}
