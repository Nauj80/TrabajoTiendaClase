package Tienda;

public class PagoApple_pay implements Pagos {
    @Override
    public void crearPago(){
        System.out.println("PagoApple_pay creado");
    }
}
