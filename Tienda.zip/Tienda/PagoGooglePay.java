package Tienda;

public class PagoGooglePay implements Pagos {
    private String dispositivo;

    public PagoGooglePay() {
        this.dispositivo = "Pixel 8 Pro";
    }

    @Override
    public void crearPago() {
        System.out.println("Pago realizado con Google Pay desde: " + dispositivo);
    }
}
