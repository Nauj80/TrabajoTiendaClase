package Tienda;

public class PagoGoogle_pay implements Pagos {
    @Override
    public void crearPago(){
        System.out.println("PagoGoogle_pay creado");
    }
}
