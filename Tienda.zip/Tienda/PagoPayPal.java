package Tienda;

public class PagoPayPal implements Pagos {
    private String correo;

    public PagoPayPal() {
        this.correo = "cliente@paypal.com";
    }

    @Override
    public void crearPago() {
        System.out.println("Pago procesado con PayPal usando el correo: " + correo);
    }
}
