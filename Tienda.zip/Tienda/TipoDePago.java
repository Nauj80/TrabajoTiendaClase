/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package Tienda;

public enum TipoDePago {
    PAYPAL,EFECTIVO,TARJETA_DEBITO,TARJETA_CREDITO,TRANSFERENCIAS,BITCOIN,CONSIGNACION,
    APPLE_PAY,GOOGLE_PAY
}
