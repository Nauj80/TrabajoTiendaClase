package Tienda;

public class UsaFactoryPagos {
    public static void main(String[] args) {
        PagoFactory pagoFactory = new PagoFactory();
        // Ejemplos de pagos
        pagoFactory.obtenerPago(TipoDePago.EFECTIVO).crearPago();
        pagoFactory.obtenerPago(TipoDePago.PAYPAL).crearPago();
        pagoFactory.obtenerPago(TipoDePago.BITCOIN).crearPago();
        pagoFactory.obtenerPago(TipoDePago.GOOGLE_PAY).crearPago();
        pagoFactory.obtenerPago(TipoDePago.APPLE_PAY).crearPago();
        pagoFactory.obtenerPago(TipoDePago.TARJETA_CREDITO).crearPago();
        pagoFactory.obtenerPago(TipoDePago.TARJETA_DEBITO).crearPago();
        pagoFactory.obtenerPago(TipoDePago.TRANSFERENCIAS).crearPago();
        pagoFactory.obtenerPago(TipoDePago.CONSIGNACION).crearPago();
    }
    }

